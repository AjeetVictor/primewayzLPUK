<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class PWI_Chat_Admin {
    private static $instance = null;
    private $client;
    public static function instance() { if ( null === self::$instance ) self::$instance = new self(); return self::$instance; }
    private function __construct() {
        $this->client = new PWI_Chat_API_Client();
        add_action( 'wp_ajax_pwi_chat_refresh_dashboard', array( $this, 'ajax_dashboard' ) );
        add_action( 'wp_ajax_pwi_chat_load_conversation', array( $this, 'ajax_conversation' ) );
        add_action( 'wp_ajax_pwi_chat_reply', array( $this, 'ajax_reply' ) );
        add_action( 'wp_ajax_pwi_chat_resolve', array( $this, 'ajax_resolve' ) );
        add_action( 'wp_ajax_pwi_chat_reopen', array( $this, 'ajax_reopen' ) );
        add_action( 'wp_ajax_pwi_chat_archive', array( $this, 'ajax_archive' ) );
        add_action( 'wp_ajax_pwi_chat_restore', array( $this, 'ajax_restore' ) );
        add_action( 'wp_ajax_pwi_chat_delete', array( $this, 'ajax_delete' ) );
        add_action( 'wp_ajax_pwi_chat_run_diagnostics', array( $this, 'ajax_diagnostics' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
    }
    public function client() { return $this->client; }
    private function allowed() { return current_user_can( 'manage_options' ); }
    public function assets() {
        if ( ! $this->is_plugin_page() ) return;
        wp_enqueue_style( 'pwi-chat-admin', PWI_URL . 'assets/admin/pwi-chat-admin.css', array(), PWI_VERSION );
        wp_enqueue_script( 'pwi-chat-admin', PWI_URL . 'assets/admin/pwi-chat-admin.js', array(), PWI_VERSION, true );
        wp_localize_script( 'pwi-chat-admin', 'pwiChatAdmin', array(
            'ajaxUrl' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'pwi_chat_admin' ), 'autoRefreshMs' => 30000,
        ) );
    }
    private function is_plugin_page() { return isset( $_GET['page'] ) && 'primewayz-integration' === sanitize_key( wp_unslash( $_GET['page'] ) ); }
    private function guard() { if ( ! $this->allowed() ) wp_send_json_error( array( 'message' => __( 'You are not permitted to access chat operations.', 'primewayz-integration' ) ), 403 ); check_ajax_referer( 'pwi_chat_admin', 'nonce' ); }
    private function post( $key, $default = '' ) { return isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : $default; }
    private function actor_payload() { $u=wp_get_current_user(); return array('externalUserId'=>'wp:'.(string)get_current_user_id(),'displayName'=>$u&&$u->exists()?(string)$u->display_name:'WordPress Administrator'); }
    public function ajax_dashboard() { $this->guard(); $inbox=$this->post('inbox','active'); $r=$this->client->dashboard($inbox); if(is_wp_error($r)) $this->send_error($r); $d=$this->data($r); $op=$this->val($d,'operator',array()); wp_send_json_success(array('html'=>$this->dashboard_html($r,$inbox),'operator'=>is_array($op)?$op:array(),'inbox'=>$inbox)); }
    public function ajax_diagnostics() { $this->guard(); $diag=$this->client->diagnostics(); if(is_wp_error($diag)) $this->send_error($diag); $dash=$this->client->dashboard(); wp_send_json_success(array('html'=>$this->diagnostics_html($diag,is_wp_error($dash)?null:$dash))); }
    public function ajax_conversation() { $this->guard(); $r=$this->client->conversation($this->post('sessionId')); if(is_wp_error($r)) $this->send_error($r); wp_send_json_success(array('html'=>$this->conversation_html($r,$this->operator_from_post()))); }
    public function ajax_reply() { $this->guard(); $text=isset($_POST['text'])?sanitize_textarea_field(wp_unslash($_POST['text'])):''; $r=$this->client->reply($this->post('sessionId'),$text,$this->post('clientActionId'),$this->actor_payload()); if(is_wp_error($r))$this->send_error($r); wp_send_json_success(array('replayed'=>!empty($r['data']['replayed']),'requestId'=>(string)$r['_requestId'])); }
    public function ajax_resolve() { $this->guard(); $r=$this->client->resolve($this->post('sessionId'),$this->post('clientActionId'),$this->actor_payload()); if(is_wp_error($r))$this->send_error($r); wp_send_json_success(array('requestId'=>(string)$r['_requestId'])); }
    public function ajax_reopen() { $this->guard(); $r=$this->client->reopen($this->post('sessionId'),$this->post('clientActionId'),$this->actor_payload()); if(is_wp_error($r))$this->send_error($r); wp_send_json_success(array('requestId'=>(string)$r['_requestId'])); }
    public function ajax_archive() { $this->guard(); $r=$this->client->archive($this->post('sessionId'),$this->post('clientActionId'),$this->actor_payload()); if(is_wp_error($r))$this->send_error($r); wp_send_json_success(array('requestId'=>(string)$r['_requestId'])); }
    public function ajax_restore() { $this->guard(); $r=$this->client->restore($this->post('sessionId'),$this->post('clientActionId'),$this->actor_payload()); if(is_wp_error($r))$this->send_error($r); wp_send_json_success(array('requestId'=>(string)$r['_requestId'])); }
    public function ajax_delete() { $this->guard(); $r=$this->client->delete_conversation($this->post('sessionId'),$this->post('clientActionId'),$this->actor_payload()); if(is_wp_error($r))$this->send_error($r); wp_send_json_success(array('requestId'=>(string)$r['_requestId'])); }
    private function operator_from_post() {
        return array(
            'canArchive' => '1' === $this->post( 'canArchive', '0' ),
            'canDelete'  => '1' === $this->post( 'canDelete', '0' ),
        );
    }
    private function send_error($e){ $d=$e->get_error_data(); $status=is_array($d)&&isset($d['http_status'])?(int)$d['http_status']:500; wp_send_json_error(array('message'=>$e->get_error_message(),'requestId'=>is_array($d)&&isset($d['request_id'])?$d['request_id']:''),$status); }
    private function data($r){ return isset($r['data'])&&is_array($r['data'])?$r['data']:array(); }
    private function val($a,$k,$default=''){ return is_array($a)&&array_key_exists($k,$a)?$a[$k]:$default; }
    private function label_status($s){ $m=array('waiting_for_team'=>'Waiting for team','admin_needed'=>'Admin needed','assistant_replied'=>'Assistant replied','team_replied'=>'Team replied','closed'=>'Closed','spam'=>'Spam','open'=>'Open'); return isset($m[$s])?$m[$s]:ucwords(str_replace('_',' ',sanitize_key($s))); }
    private function actor($a){ $m=array('visitor'=>'Visitor','assistant'=>'Primewayz Assistant','team'=>'Primewayz Team'); return isset($m[$a])?$m[$a]:__('Unknown','primewayz-integration'); }
    private function presence($s){ $m=array('available'=>'Online','not_online'=>'Offline','away'=>'Away','offline'=>'Offline'); return isset($m[$s])?$m[$s]:ucwords(str_replace('_',' ',sanitize_key($s))); }
    private function dt($iso){ $ts=strtotime((string)$iso); return $ts?wp_date('j M Y, g:i A',$ts):'Not reported'; }
    private function intent($v){ return is_string($v)&&''!==trim($v)?trim($v):'No intent selected'; }
    private function activity($a){ return $this->dt($this->val($a,'lastActivityAt',$this->val($a,'lastActivity',''))); }
    private function page_label($v){ $v=(string)$v; if(''===$v||'/'===$v)return 'Homepage'; $path=wp_parse_url($v,PHP_URL_PATH); $path=is_string($path)?$path:$v; return '/'===trim($path)?'Homepage':$path; }
    private function tone_for_status($s){ if(in_array($s,array('waiting_for_team','admin_needed'),true))return 'warn'; if(in_array($s,array('closed','spam'),true))return 'neutral'; if(in_array($s,array('team_replied','assistant_replied','open'),true))return 'good'; return 'neutral'; }
    private function badge($text,$tone='neutral'){ return '<span class="pwi-badge pwi-badge--'.esc_attr($tone).'">'.esc_html($text).'</span>'; }

    private function nested($a,$path,$default=''){ foreach((array)$path as $k){ if(!is_array($a)||!array_key_exists($k,$a)) return $default; $a=$a[$k]; } return $a; }
    private function first_value($sources,$keys,$default=''){ foreach($sources as $src){ if(!is_array($src))continue; foreach($keys as $k){ if(array_key_exists($k,$src)&&null!==$src[$k]&&''!==$src[$k]) return $src[$k]; } } return $default; }
    private function visitor_presence($visitor,$session){ $raw=strtolower((string)$this->first_value(array($session,$visitor),array('presence','presenceStatus','onlineStatus','status'),'')); if(true===$this->first_value(array($session,$visitor),array('online','isOnline'),false))$raw='online'; $map=array('online'=>'Online','active'=>'Online','idle'=>'Idle','away'=>'Idle','offline'=>'Offline','not_online'=>'Offline'); return isset($map[$raw])?$map[$raw]:'Not reported'; }
    private function presence_tone($label){ return 'Online'===$label?'good':('Idle'===$label?'warn':'neutral'); }
    private function display_value($v,$fallback='Not provided'){ return (is_scalar($v)&&''!==trim((string)$v))?(string)$v:$fallback; }
    private function visitor_context($conv,$d){
        $visitor=$this->val($conv,'visitor',$this->val($d,'visitor',array())); if(!is_array($visitor))$visitor=array();
        $session=$this->val($conv,'session',$this->val($d,'session',array())); if(!is_array($session))$session=array();
        $location=$this->val($session,'location',$this->val($visitor,'location',array())); if(!is_array($location))$location=array();
        return array($visitor,$session,$location);
    }
    private function location_label($location){ $parts=array(); foreach(array('city','region','country') as $k){ $v=$this->val($location,$k,''); if(is_string($v)&&''!==trim($v)&&!in_array(trim($v),$parts,true))$parts[]=trim($v); } return $parts?implode(', ',$parts):'Not reported'; }
    private function recent_presence($c){
        $visitor=$this->val($c,'visitor',array()); if(!is_array($visitor))$visitor=array();
        $session=$this->val($c,'session',array()); if(!is_array($session))$session=array();
        $raw=$this->first_value(array($c,$session,$visitor),array('visitorPresence','presence','presenceStatus','onlineStatus'),'');
        if(is_string($raw)&&''!==trim($raw)){
            $key=strtolower(trim($raw));
            $map=array('online'=>'Online','active'=>'Online','available'=>'Online','idle'=>'Idle','away'=>'Idle','offline'=>'Offline','not_online'=>'Offline');
            if(isset($map[$key])) return $map[$key];
        }
        return $this->visitor_presence($visitor,$session);
    }
    private function recent_last_seen($c){
        $visitor=$this->val($c,'visitor',array()); if(!is_array($visitor))$visitor=array();
        $session=$this->val($c,'session',array()); if(!is_array($session))$session=array();
        return $this->first_value(array($c,$session,$visitor),array('lastSeenAt','visitorLastSeenAt','lastSeen','heartbeatAt'),'');
    }
    public function dashboard_html($r,$inbox='active'){
        $d=$this->data($r); $service=$this->val($d,'service',array()); $attention=$this->val($d,'attention',array()); $recent=$this->val($d,'recentConversations',array()); $team=$this->val($d,'team',$this->val($d,'presence',$this->val($d,'teamAvailability',array()))); $full=$this->val($d,'fullAdmin',array());
        $status=(string)$this->val($service,'status','unavailable'); $healthy='healthy'===$status; $enabled=(bool)$this->val($service,'chatEnabled',false); $accept=(bool)$this->val($service,'canAcceptMessages',false); $count=(int)$this->val($attention,'count',0); $pstatus=(string)$this->val($team,'status','offline');
        $inbox=in_array($inbox,array('active','archived'),true)?$inbox:'active';
        ob_start(); ?>
        <div class="pwi-chat-dashboard" data-inbox="<?php echo esc_attr($inbox); ?>">
          <section class="pwi-section pwi-section--status"><div class="pwi-section__head"><div><span class="pwi-eyebrow">Live tenant state</span><h2>Operational Status</h2></div><span class="pwi-refresh-note">Auto-refreshes every 30 seconds</span></div>
          <div class="pwi-status-grid">
            <div class="pwi-status-card"><span>Chat service</span><strong><?php echo $this->badge($healthy?'Healthy':ucwords(str_replace('_',' ',$status)),$healthy?'good':'warn'); ?></strong></div>
            <div class="pwi-status-card"><span>Visitor chat</span><strong><?php echo $this->badge($enabled?'Enabled':'Disabled',$enabled?'good':'neutral'); ?></strong></div>
            <div class="pwi-status-card"><span>Messages</span><strong><?php echo $this->badge($accept?'Accepting':'Not accepting',$accept?'good':'warn'); ?></strong></div>
            <div class="pwi-status-card"><span>Primewayz team availability</span><strong><?php echo $this->badge($this->presence($pstatus),'available'===$pstatus?'good':'neutral'); ?></strong></div>
            <div class="pwi-status-card"><span>Needs attention</span><strong><?php echo esc_html((string)$count); ?></strong></div>
          </div>
          <?php if (0===$count): ?><p class="pwi-inline-state pwi-inline-state--good"><strong>All clear.</strong> No conversations currently need attention.</p><?php else:?><p class="pwi-inline-state pwi-inline-state--warn"><strong><?php echo esc_html((string)$count); ?> conversation(s) need attention.</strong> Review the queue below.</p><?php endif; ?></section>
          <section class="pwi-section"><div class="pwi-table-head"><div><span class="pwi-eyebrow">Tenant inbox</span><h2><?php echo 'archived'===$inbox?'Archived Conversations':'Recent Conversations'; ?></h2><p class="description">Tenant-scoped conversations supplied by the Primewayz UK parent chat platform.</p></div><div class="pwi-inbox-controls"><div class="pwi-inbox-filter" role="group" aria-label="Conversation inbox"><button type="button" class="button pwi-inbox-tab<?php echo 'active'===$inbox?' button-primary':''; ?>" data-inbox="active" aria-pressed="<?php echo 'active'===$inbox?'true':'false'; ?>">Active</button><button type="button" class="button pwi-inbox-tab<?php echo 'archived'===$inbox?' button-primary':''; ?>" data-inbox="archived" aria-pressed="<?php echo 'archived'===$inbox?'true':'false'; ?>">Archived</button></div><button type="button" class="button pwi-refresh">Refresh</button></div></div>
          <?php if (is_array($recent)&&count($recent)): ?>
          <div class="pwi-table-wrap"><table class="widefat striped pwi-conversation-table"><thead><tr><th>Visitor</th><th>Presence</th><th>Interest</th><th>Page</th><th>Latest message</th><th>Last response</th><th>Last activity</th><th>Last seen</th><th>Status</th><th>Attention</th><th>Action</th></tr></thead><tbody>
          <?php foreach($recent as $c): if(!is_array($c))continue; $sid=(string)$this->val($c,'sessionId',''); $vp=$this->recent_presence($c); $vls=$this->recent_last_seen($c); $needs=!empty($c['needsAttention']); ?>
            <tr class="<?php echo $needs?'pwi-row--attention':''; ?>"><td><strong class="pwi-visitor-name"><?php echo esc_html((string)$this->val($c,'visitorLabel','Visitor')); ?></strong></td><td><?php echo $this->badge($vp,$this->presence_tone($vp)); ?></td><td><?php echo esc_html((string)$this->intent($this->val($c,'intent',null))); ?></td><td><?php echo esc_html($this->page_label($this->val($c,'originatingPage','/'))); ?></td><td class="pwi-preview"><?php echo esc_html((string)$this->val($c,'lastMessagePreview','')); ?></td><td><?php echo esc_html($this->actor((string)$this->val($c,'lastActor',''))); ?></td><td><?php echo esc_html($this->activity($c)); ?></td><td><?php echo esc_html($vls?$this->dt($vls):'Not reported'); ?></td><td><?php echo $this->badge($this->label_status((string)$this->val($c,'status','open')),$this->tone_for_status((string)$this->val($c,'status','open'))); ?></td><td><?php echo $needs?$this->badge('Needs attention','warn'):'<span class="pwi-attention-clear" aria-label="No attention required">Clear</span>'; ?></td><td><button type="button" class="button button-small pwi-view-conversation" data-session-id="<?php echo esc_attr($sid); ?>">Manage</button></td></tr>
          <?php endforeach; ?></tbody></table></div>
          <?php else: ?><p class="pwi-empty"><?php echo 'archived'===$inbox?'No archived conversations.':'No Primewayz.com conversations yet.'; ?></p><?php endif; ?>
          </section><?php echo $this->full_admin_html($full); ?>
        </div><?php return ob_get_clean();
    }
    private function full_admin_html($full){ $url=(string)$this->val($full,'url',''); $pre=(bool)$this->val($full,'tenantPreselected',false); ob_start(); ?><div class="pwi-full-admin"><div><strong>Parent Chat Administration</strong><p>Primewayz UK remains the authoritative parent chat platform. Use it for platform-level administration beyond this tenant console.</p><?php if(!$pre):?><p class="description">Select Primewayz Infotech from the entity selector after opening the parent admin.</p><?php endif;?></div><?php if($url):?><a class="button button-primary" href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer">Open Primewayz UK Chat Admin ↗</a><?php endif;?></div><?php return ob_get_clean(); }
    public function conversation_html($r,$operator=array()){
        $d=$this->data($r); $conv=$this->val($d,'conversation',$d); $messages=$this->val($conv,'messages',$this->val($d,'messages',array()));
        $sid=(string)$this->val($conv,'sessionId',$this->val($d,'sessionId','')); $status=(string)$this->val($conv,'status','open'); $closed=in_array($status,array('closed','spam'),true);
        $lifecycle=(string)$this->val($conv,'lifecycle',$this->val($d,'lifecycle','active')); $archived='archived'===$lifecycle;
        $can_archive=!empty($operator['canArchive']); $can_delete=!empty($operator['canDelete']);
        list($visitor,$session,$location)=$this->visitor_context($conv,$d);
        $name=$this->first_value(array($visitor,$conv),array('name','displayName','visitorLabel'),'Visitor');
        $email=$this->first_value(array($visitor,$conv),array('email','visitorEmail'),''); $phone=$this->first_value(array($visitor,$conv),array('phone','phoneNumber','visitorPhone'),'');
        $presence=$this->visitor_presence($visitor,$session); $lastSeen=$this->first_value(array($session,$visitor),array('lastSeenAt','lastSeen','heartbeatAt'),'');
        $firstSeen=$this->first_value(array($visitor,$session),array('firstSeenAt','firstSeen','createdAt'),'');
        $currentPage=$this->first_value(array($session,$conv),array('currentPage','page','pageUrl'),''); $origin=$this->first_value(array($session,$conv),array('originatingPage','originPage','entryPage'),'/');
        $browser=$this->first_value(array($session),array('browser','browserName'),''); $os=$this->first_value(array($session),array('os','operatingSystem'),''); $device=$this->first_value(array($session),array('device','deviceType'),'');
        $returning=$this->first_value(array($visitor),array('returning','isReturning'),null); $identity=$this->first_value(array($visitor),array('identityStatus'),'');
        ob_start(); ?>
        <div class="pwi-conversation pwi-workspace" data-session-id="<?php echo esc_attr($sid); ?>" data-status="<?php echo esc_attr($status); ?>" data-lifecycle="<?php echo esc_attr($lifecycle); ?>">
          <header class="pwi-workspace-head"><div><span class="pwi-eyebrow">Tenant conversation</span><h2 id="pwi-transcript-title"><?php echo esc_html($this->display_value($name,'Visitor')); ?></h2></div><div class="pwi-workspace-badges"><?php echo $this->badge($presence,$this->presence_tone($presence)); ?><?php echo $this->badge($this->label_status($status),$this->tone_for_status($status)); ?><?php if($archived) echo $this->badge('Archived','neutral'); ?><?php if($can_archive||$can_delete): ?><div class="pwi-actions-menu"><button type="button" class="button pwi-actions-toggle" aria-haspopup="menu" aria-expanded="false" aria-controls="pwi-actions-list">Actions</button><ul id="pwi-actions-list" class="pwi-actions-list" role="menu" hidden><?php if($can_archive&&!$archived):?><li role="none"><button type="button" class="pwi-archive-conversation" role="menuitem">Archive conversation</button></li><?php endif; ?><?php if($can_archive&&$archived):?><li role="none"><button type="button" class="pwi-restore-conversation" role="menuitem">Restore from archive</button></li><?php endif; ?><?php if($can_delete):?><li role="none"><button type="button" class="pwi-delete-conversation pwi-actions-danger" role="menuitem">Permanently delete</button></li><?php endif; ?></ul></div><?php endif; ?></div></header>
          <div class="pwi-workspace-grid">
            <aside class="pwi-context-panel">
              <section><h3>Visitor</h3><dl class="pwi-detail-list"><div><dt>Presence</dt><dd><?php echo $this->badge($presence,$this->presence_tone($presence)); ?></dd></div><div><dt>Last seen</dt><dd><?php echo esc_html($lastSeen?$this->dt($lastSeen):'Not reported'); ?></dd></div><div><dt>First seen</dt><dd><?php echo esc_html($firstSeen?$this->dt($firstSeen):'Not reported'); ?></dd></div><div><dt>Visitor type</dt><dd><?php echo esc_html(null===$returning?($identity?$this->display_value($identity):'Not reported'):($returning?'Returning':'New')); ?></dd></div></dl></section>
              <section><h3>Contact</h3><dl class="pwi-detail-list"><div><dt>Name</dt><dd><?php echo esc_html($this->display_value($name)); ?></dd></div><div><dt>Email</dt><dd><?php echo esc_html($this->display_value($email)); ?></dd></div><div><dt>Phone</dt><dd><?php echo esc_html($this->display_value($phone)); ?></dd></div></dl><p class="pwi-context-note">Contact data is managed by the Primewayz service-provider platform and is read-only here.</p></section>
              <section><h3>Session context</h3><dl class="pwi-detail-list"><div><dt>Current page</dt><dd><?php echo esc_html($currentPage?$this->page_label($currentPage):'Not reported'); ?></dd></div><div><dt>Originating page</dt><dd><?php echo esc_html($this->page_label($origin)); ?></dd></div><div><dt>Location</dt><dd><?php echo esc_html($this->location_label($location)); ?></dd></div><div><dt>Device</dt><dd><?php echo esc_html($this->display_value($device,'Not reported')); ?></dd></div><div><dt>Browser</dt><dd><?php echo esc_html($this->display_value($browser,'Not reported')); ?></dd></div><div><dt>OS</dt><dd><?php echo esc_html($this->display_value($os,'Not reported')); ?></dd></div></dl><?php if('Not reported'!==$this->location_label($location)):?><p class="pwi-context-note">Approximate service-provider-derived location. Raw IP is not exposed to WordPress.</p><?php endif;?></section>
            </aside>
            <main class="pwi-thread-panel">
              <div class="pwi-conversation-summary"><div><span>Interest</span><strong><?php echo esc_html((string)$this->intent($this->val($conv,'intent',null))); ?></strong></div><div><span>Last activity</span><strong><?php echo esc_html($this->activity($conv)); ?></strong></div></div>
              <div class="pwi-messages"><?php if(is_array($messages)) foreach($messages as $m): if(!is_array($m))continue; $deleted=!empty($m['deleted']); ?><div class="pwi-message pwi-message--<?php echo esc_attr(sanitize_key((string)$this->val($m,'actor','visitor'))); ?>"><div class="pwi-message-meta"><strong><?php echo esc_html($this->actor((string)$this->val($m,'actor',''))); ?></strong><span><?php echo esc_html($this->dt($this->val($m,'createdAt',''))); ?></span></div><p><?php echo esc_html($deleted?'Message deleted':(string)$this->val($m,'text','')); ?></p><?php if(!$deleted&&!empty($m['edited'])):?><small>Edited</small><?php endif;?></div><?php endforeach; ?></div>
              <?php if(!empty($conv['hasMore'])||!empty($d['hasMore'])):?><p class="notice notice-info inline">Showing the latest messages supplied by the operational API. Open the parent admin for complete platform history.</p><?php endif; ?>
              <div class="pwi-conversation-actions"><div class="pwi-action-feedback" role="status" aria-live="polite"></div><?php if(!$closed):?><label for="pwi-chat-reply"><strong>Reply as Primewayz Team</strong></label><textarea id="pwi-chat-reply" class="large-text pwi-reply-text" rows="4" maxlength="4000" placeholder="Type a reply…"></textarea><div class="pwi-action-row"><button type="button" class="button button-primary pwi-send-reply">Send Reply</button><button type="button" class="button pwi-resolve-conversation">Resolve Conversation</button></div><?php elseif('closed'===$status):?><div class="pwi-action-row"><button type="button" class="button button-primary pwi-reopen-conversation">Reopen Conversation</button></div><?php else:?><p class="description">This conversation cannot be replied to from WordPress in its current state.</p><?php endif;?></div>
            </main>
          </div>
        </div><?php return ob_get_clean();
    }
    public function diagnostics_html($r,$dashboard=null){ $d=$this->data($r); $tenant=isset($r['tenant'])&&is_array($r['tenant'])?$r['tenant']:array(); $dd=is_array($dashboard)?$this->data($dashboard):array(); $service=$this->val($dd,'service',$this->val($d,'service',array())); $db=$this->val($d,'database',array()); $team=$this->val($dd,'team',$this->val($d,'team',$this->val($d,'presence',$this->val($d,'teamAvailability',array())))); $cap=array_key_exists('chatEnabled',$service)?(!empty($service['chatEnabled'])?'Enabled':'Disabled'):'Not reported'; $msg=array_key_exists('canAcceptMessages',$service)?(!empty($service['canAcceptMessages'])?'Accepting':'Not accepting'):'Not reported'; $p=array_key_exists('status',$team)?$this->presence((string)$team['status']):'Not reported'; $name=(string)$this->val($tenant,'displayName',$this->val($tenant,'name','Primewayz Infotech')); $rows=array('Operational API'=>'Connected','Authentication'=>'Valid','Tenant'=>$name,'Tenant binding'=>'Valid','Chat capability'=>$cap,'Messages'=>$msg,'Database'=>(string)$this->val($db,'status',$this->val($d,'databaseStatus','Reachable')),'Team availability'=>$p,'API version'=>(string)$r['apiVersion'],'Last request ID'=>(string)$r['_requestId'],'Last successful check'=>wp_date('j M Y, g:i A')); ob_start(); ?><table class="widefat striped pwi-diagnostics"><tbody><?php foreach($rows as $k=>$v):?><tr><th scope="row"><?php echo esc_html($k);?></th><td><?php echo esc_html($v);?></td></tr><?php endforeach;?></tbody></table><?php return ob_get_clean(); }
}
