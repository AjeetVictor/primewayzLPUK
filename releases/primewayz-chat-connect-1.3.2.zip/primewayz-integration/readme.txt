=== Primewayz Chat Connect ===
Contributors: primewayz
Stable tag: 1.3.2
Requires PHP: 7.4

Single Primewayz.com integration layer for the public visitor chat widget and delegated Primewayz Infotech tenant chat administration.

== Architecture ==
Public visitor browser -> vendored pw-chat.js -> Primewayz UK public APIs.
WordPress administrator browser -> WordPress PHP -> authenticated Primewayz UK operational endpoint.

The operational bearer credential is never sent to browser JavaScript. Define it manually in wp-config.php:

define( 'PWI_WORDPRESS_CHAT_INTEGRATION_TOKEN', 'replace-with-production-secret' );

Do not add the real token to this plugin or WordPress database.

== Admin ==
Settings > Primewayz Chat Connect provides Overview, Chat, Settings and Diagnostics tabs.
The Chat dashboard provides tenant-scoped conversation visibility, transcript access, human replies, resolve, reopen, archive, restore and authorized permanent delete through the authenticated Primewayz UK operational API. An Active / Archived inbox filter is included. Primewayz UK remains the authoritative parent chat administration platform.


= 1.3.2 =
* Vendors immutable visitor widget 1.3.2 with the shared presence colour palette (online green, away amber, offline grey, automated blue, unavailable red).
* Labels team status not_online as Automated assistance (blue) only when automated guidance is confirmed available; offline remains grey Offline.
* Display name and Settings menu title: Primewayz Chat Connect. Internal slug primewayz-integration and all settings, credentials, permissions and conversation actions are unchanged.
* Retains GA4/GTM analytics from widget 1.3.1.

== Privacy ==
The public chat widget communicates with the Primewayz UK backend. Operational chat data remains stored in the shared Primewayz backend and is not duplicated into WordPress. Administrators should ensure the public Privacy Policy accurately describes the chat functionality before public rollout.


= 1.1.6 =
* Hardened the server-to-server operational API boundary without changing the existing chat contract or tenant identity.
* Production API requests carrying the WordPress integration bearer credential are pinned to https://uk.primewayz.com; localhost remains available only in explicit local/development WordPress environments.
* Preserved the fixed Primewayz Infotech tenant binding (pw-infotech / IN), dashboard, diagnostics, conversation, reply, resolve and reopen actions, visitor widget, session storage and admin AJAX flows.
* Clarified that the WordPress administrator session authorizes the local tenant console while Host operations use the dedicated server-side integration credential; browser Host cookies are not used.

= 1.1.5 =
* Added visitor Presence and Last Seen directly to Recent Conversations for faster tenant triage.
* Added clearer attention-row and presence/status presentation while preserving authoritative service-provider data ownership.
* Improved tenant inbox responsiveness for the wider operational dataset.
* Improved conversation modal keyboard focus handling and focus restoration.
* Preserved the validated reply, idempotency, resolve, reopen, diagnostics, Live/Preview/Disabled modes and server-only bearer-token boundary.
* Remains forward-compatible with additive visitor telemetry supplied by the Primewayz UK service-provider API.

= 1.1.1 =
* Upgraded the existing Primewayz Integration plugin in place; no duplicate chat plugin created.
* Corrected operational team presence mapping to data.team.status.
* Corrected diagnostics so missing operational fields are not treated as false; authoritative dashboard state is used where available.
* Added delegated tenant-admin reply, resolve and reopen actions through WordPress PHP.
* Added retry-safe clientActionId handling for human replies and lifecycle actions.
* Preserved server-only bearer credential, tenant binding, public widget loader, settings and admin preview behaviour.

= 1.1.3 =
* Role-aware frontend for logged-in WordPress administrators.
* Explicit visitor-chat preview with isolated preview session storage.
* Correct lastActivityAt mapping and clearer intent/status presentation.
* Redesigned Overview, Chat, Settings and Diagnostics administration UI.
* Stronger success, warning and error state semantics.

= 1.1.2 ==
* Replaced ambiguous Chat Enabled + Admin Preview checkboxes with explicit Live, Admin Preview Only and Disabled visitor-chat modes.
* Migrates existing settings automatically without changing current behaviour on upgrade.
* Added visible current WordPress tenant-administrator identity to Chat Operations; no separate chat login is required.
* Improved admin visual hierarchy for operational matrices, success, warning and error states.
* Preserved the validated Primewayz UK API contract, delegated reply/resolve/reopen flows, public chat asset and server-only credential boundary.

== Primewayz Chat Connect 1.2.0 ==
- Renames the WordPress integration product to Primewayz Chat Connect without changing the installed folder or option namespace.
- Preserves public visitor widget, preview/disabled settings, delegated WordPress chat API and existing credential constant.
- Adds a separate optional installation credential, five-minute WP-Cron heartbeat and manual diagnostic control.
- Central Host/Owner must first create and authorize the WordPress installation and provide its secret. Activation/heartbeat field compatibility must be confirmed against the deployed platform before enabling credentials on production.
- In wp-config.php ABOVE the WordPress stop-editing line, supply ONLY values issued by the Host/Owner:
  define('PWI_CHAT_CONNECT_INSTALLATION_ID', 'HOST_ISSUED_INSTALLATION_ID');
  define('PWI_CHAT_CONNECT_TOKEN', 'HOST_ISSUED_SECRET_32_CHARS_OR_LONGER');
- Keep PWI_WORDPRESS_CHAT_INTEGRATION_TOKEN unchanged for existing delegated operations; do not reuse it as the new connector secret.
- WP-Cron is traffic-dependent; five-minute scheduling is best-effort unless a server cron is configured.
- Never infer connection health from operational API connectivity. Check the central Integrations dashboard for a verified heartbeat.
- This build does not auto-activate, rotate credentials, or change entitlement; those are central Host/Owner actions.

== Primewayz Chat Connect 1.3.1 ==
* Authorized conversation lifecycle: Archive, Restore and Permanently delete via the Actions menu when the Host credential grants chat:archive / chat:delete.
* Active and Archived inbox filters with list refresh after successful lifecycle operations.
* Confirmation dialogs and loading feedback for destructive actions; failures preserve modal state with actionable errors.
* Vendors shared widget build 1.3.1 (free-text-first composer with optional compact topic chips and Something else).
* Preserves Refresh loading behavior, email-signature deep-link, Live / Admin Preview / Disabled modes, installation settings and credentials.
* Does not introduce a second WordPress plugin; upgrades the existing Primewayz Chat Connect installation in place.

== Primewayz Chat Connect 1.2.1 ==
* Email deep-link compatibility bridge: exact ?pw_chat=open opens the existing authorized chat widget after load.
* Bridge is enqueued only when visitor widget is permitted by the existing WordPress visibility gate.
* Added refreshing state, in-flight request deduplication and failure recovery to tenant inbox refresh button.
* Bundled widget remains build 1.0.1; no compiled widget source was edited.
* Conversation archive/deletion and tenant-configurable choices require central API / shared-widget changes and are not implemented by this update.
