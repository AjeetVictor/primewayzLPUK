(function () {
  'use strict';
  var cfg = window.pwiChatAdmin;
  if (!cfg) return;

  var root = document.getElementById('pwi-chat-dashboard-root');
  var modal = document.getElementById('pwi-chat-modal');
  var body = document.getElementById('pwi-chat-modal-body');
  var closeBtn = document.getElementById('pwi-chat-modal-close');
  var lastTrigger = null;
  var errorCount = 0;
  var timer = null;
  var refreshing = false;
  var currentInbox = 'active';
  var operator = {
    canArchive: false,
    canDelete: false,
  };

  function post(action, data) {
    var f = new FormData();
    f.append('action', action);
    f.append('nonce', cfg.nonce);
    Object.keys(data || {}).forEach(function (k) {
      f.append(k, data[k]);
    });
    return fetch(cfg.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: f })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (!j.success) throw new Error((j.data && j.data.message) ? j.data.message : 'Request failed.');
        return j.data;
      });
  }

  function actionId(el) {
    if (el.dataset.clientActionId) return el.dataset.clientActionId;
    var id = (window.crypto && crypto.randomUUID)
      ? crypto.randomUUID()
      : ('wp-' + Date.now() + '-' + Math.random().toString(16).slice(2));
    el.dataset.clientActionId = id;
    return id;
  }

  function clearActionId(el) {
    delete el.dataset.clientActionId;
  }

  function feedback(msg, isError) {
    var f = body && body.querySelector('.pwi-action-feedback');
    if (!f) return;
    f.textContent = msg || '';
    f.classList.toggle('pwi-action-feedback--error', !!isError);
  }

  function setOperator(next) {
    if (!next || typeof next !== 'object') return;
    operator.canArchive = !!next.canArchive;
    operator.canDelete = !!next.canDelete;
  }

  function closeActionsMenu() {
    if (!body) return;
    var toggle = body.querySelector('.pwi-actions-toggle');
    var list = body.querySelector('.pwi-actions-list');
    if (toggle) toggle.setAttribute('aria-expanded', 'false');
    if (list) list.hidden = true;
  }

  function runLifecycle(button, ajaxAction, loadingLabel, confirmMessage, closeAfter) {
    if (confirmMessage && !window.confirm(confirmMessage)) return;
    button.disabled = true;
    closeActionsMenu();
    feedback(loadingLabel, false);
    post(ajaxAction, {
      sessionId: button.closest('.pwi-conversation').getAttribute('data-session-id'),
      clientActionId: actionId(button),
    }).then(function () {
      clearActionId(button);
      if (closeAfter) {
        close();
        return refresh();
      }
      return reloadConversation(button.closest('.pwi-conversation').getAttribute('data-session-id'))
        .then(refresh);
    }).catch(function (e) {
      feedback(e.message, true);
      button.disabled = false;
    });
  }

  function bind() {
    document.querySelectorAll('.pwi-refresh').forEach(function (b) {
      b.onclick = function () { refresh(); };
    });
    document.querySelectorAll('.pwi-inbox-tab').forEach(function (b) {
      b.onclick = function () {
        var next = b.getAttribute('data-inbox') || 'active';
        if (next === currentInbox) return;
        currentInbox = next;
        refresh();
      };
    });
    document.querySelectorAll('.pwi-view-conversation').forEach(function (b) {
      b.onclick = function () {
        lastTrigger = b;
        openConversation(b.getAttribute('data-session-id'));
      };
    });
    if (!body) return;
    var conv = body.querySelector('.pwi-conversation');
    if (!conv) return;
    var sid = conv.getAttribute('data-session-id');
    var send = body.querySelector('.pwi-send-reply');
    var resolve = body.querySelector('.pwi-resolve-conversation');
    var reopen = body.querySelector('.pwi-reopen-conversation');
    var archive = body.querySelector('.pwi-archive-conversation');
    var restore = body.querySelector('.pwi-restore-conversation');
    var del = body.querySelector('.pwi-delete-conversation');
    var text = body.querySelector('.pwi-reply-text');
    var actionsToggle = body.querySelector('.pwi-actions-toggle');
    var actionsList = body.querySelector('.pwi-actions-list');

    if (actionsToggle && actionsList) {
      actionsToggle.onclick = function () {
        var open = actionsToggle.getAttribute('aria-expanded') === 'true';
        actionsToggle.setAttribute('aria-expanded', open ? 'false' : 'true');
        actionsList.hidden = open;
      };
    }

    if (send) {
      send.onclick = function () {
        var value = text ? text.value.trim() : '';
        if (!value) {
          feedback('Enter a reply before sending.', true);
          if (text) text.focus();
          return;
        }
        send.disabled = true;
        feedback('Sending reply…', false);
        post('pwi_chat_reply', {
          sessionId: sid,
          text: value,
          clientActionId: actionId(send),
        }).then(function (d) {
          clearActionId(send);
          feedback(d.replayed ? 'Reply already recorded. Refreshing conversation…' : 'Reply sent. Refreshing conversation…', false);
          return reloadConversation(sid);
        }).catch(function (e) {
          feedback(e.message, true);
          send.disabled = false;
        });
      };
    }
    if (resolve) {
      resolve.onclick = function () {
        runLifecycle(resolve, 'pwi_chat_resolve', 'Resolving conversation…', 'Resolve this conversation?', false);
      };
    }
    if (reopen) {
      reopen.onclick = function () {
        runLifecycle(reopen, 'pwi_chat_reopen', 'Reopening conversation…', null, false);
      };
    }
    if (archive) {
      archive.onclick = function () {
        runLifecycle(archive, 'pwi_chat_archive', 'Archiving conversation…', 'Archive this conversation? It will move to the Archived inbox.', true);
      };
    }
    if (restore) {
      restore.onclick = function () {
        runLifecycle(restore, 'pwi_chat_restore', 'Restoring conversation…', null, true);
      };
    }
    if (del) {
      del.onclick = function () {
        runLifecycle(
          del,
          'pwi_chat_delete',
          'Deleting conversation…',
          'Permanently delete this conversation? Message content will be removed and cannot be restored. Lead contact details are retained.',
          true,
        );
      };
    }
  }

  function refresh() {
    if (!root || refreshing) return Promise.resolve();
    refreshing = true;
    root.setAttribute('aria-busy', 'true');
    var buttons = Array.prototype.slice.call(root.querySelectorAll('.pwi-refresh'));
    buttons.forEach(function (b) {
      b.disabled = true;
      b.setAttribute('aria-busy', 'true');
      b.dataset.originalLabel = b.textContent;
      b.textContent = 'Refreshing…';
    });
    return post('pwi_chat_refresh_dashboard', { inbox: currentInbox }).then(function (d) {
      if (d.inbox === 'active' || d.inbox === 'archived') currentInbox = d.inbox;
      setOperator(d.operator);
      root.innerHTML = d.html;
      errorCount = 0;
      bind();
    }).catch(function (e) {
      root.insertAdjacentHTML('afterbegin', '<div class="pwi-error" role="alert"></div>');
      root.firstElementChild.textContent = e.message;
      errorCount++;
      if (errorCount >= 3) stop();
      throw e;
    }).finally(function () {
      refreshing = false;
      root.removeAttribute('aria-busy');
      buttons.forEach(function (b) {
        if (b.isConnected) {
          b.disabled = false;
          b.removeAttribute('aria-busy');
          b.textContent = b.dataset.originalLabel || 'Refresh';
          delete b.dataset.originalLabel;
        }
      });
    });
  }

  function reloadConversation(id) {
    return post('pwi_chat_load_conversation', {
      sessionId: id,
      canArchive: operator.canArchive ? '1' : '0',
      canDelete: operator.canDelete ? '1' : '0',
    }).then(function (d) {
      body.innerHTML = d.html;
      bind();
    });
  }

  function openConversation(id) {
    if (!modal || !body) return;
    modal.hidden = false;
    modal.setAttribute('aria-modal', 'true');
    body.innerHTML = '<p class="pwi-loading">Loading conversation…</p>';
    closeBtn.focus();
    reloadConversation(id).catch(function (e) {
      body.innerHTML = '<div class="pwi-error" role="alert"></div>';
      body.firstElementChild.textContent = e.message;
    });
  }

  function close() {
    if (!modal) return;
    modal.hidden = true;
    modal.removeAttribute('aria-modal');
    body.innerHTML = '';
    if (lastTrigger) lastTrigger.focus();
  }

  function stop() {
    if (timer) {
      clearInterval(timer);
      timer = null;
    }
  }

  if (closeBtn) closeBtn.addEventListener('click', close);
  if (modal) {
    modal.addEventListener('click', function (e) {
      if (e.target.classList.contains('pwi-modal-backdrop')) close();
    });
  }
  document.addEventListener('keydown', function (e) {
    if (!modal || modal.hidden) return;
    if (e.key === 'Escape') {
      var list = body && body.querySelector('.pwi-actions-list');
      if (list && !list.hidden) {
        closeActionsMenu();
        var toggle = body.querySelector('.pwi-actions-toggle');
        if (toggle) toggle.focus();
        return;
      }
      close();
      return;
    }
    if (e.key === 'Tab') {
      var focusable = modal.querySelectorAll('a[href],button:not([disabled]),textarea:not([disabled]),input:not([disabled]),select:not([disabled]),[tabindex]:not([tabindex="-1"])');
      if (!focusable.length) return;
      var first = focusable[0];
      var last = focusable[focusable.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
  });
  document.addEventListener('click', function (e) {
    if (!body || !body.contains(e.target)) return;
    if (e.target.closest('.pwi-actions-menu')) return;
    closeActionsMenu();
  });
  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState === 'hidden') stop();
    else start();
  });

  function start() {
    if (!root || timer || errorCount >= 3) return;
    timer = setInterval(function () {
      if (document.visibilityState === 'visible') refresh().catch(function () {});
    }, cfg.autoRefreshMs || 30000);
  }

  if (root && root.querySelector('.pwi-chat-dashboard')) {
    currentInbox = root.querySelector('.pwi-chat-dashboard').getAttribute('data-inbox') || 'active';
  }
  bind();
  refresh().catch(function () {});
  start();
})();
