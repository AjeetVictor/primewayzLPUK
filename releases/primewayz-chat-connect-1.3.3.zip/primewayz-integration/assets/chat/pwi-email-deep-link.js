/* Primewayz Chat Connect: deep-link bridge for the bundled legacy widget. */
(function (win, doc) {
  'use strict';
  var wantsOpen = false;
  try {
    wantsOpen = new URLSearchParams(win.location.search).get('pw_chat') === 'open';
  } catch (_) { return; }
  if (!wantsOpen) { return; }

  // Only called when WordPress has actually enqueued the authorized widget.
  // The global API queues an open request while its async setup completes.
  function requestOpen() {
    if (!win.PrimewayzChat || typeof win.PrimewayzChat.open !== 'function') {
      return;
    }
    win.PrimewayzChat.open();
  }

  if (doc.readyState === 'complete') {
    requestOpen();
  } else {
    win.addEventListener('load', requestOpen, { once: true });
  }
})(window, document);
