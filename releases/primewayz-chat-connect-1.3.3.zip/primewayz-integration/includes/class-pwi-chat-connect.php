<?php
/**
 * Primewayz Chat Connect transport. The existing WordPress operational credential
 * remains independent of per-installation Chat Connect credentials.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class PWI_Chat_Connect {
    const CRON_HOOK = 'pwi_chat_connect_heartbeat';
    const STATUS_KEY = 'pwi_chat_connect_status';
    const API_ORIGIN = 'https://uk.primewayz.com';

    public static function init() {
        add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) );
        add_action( self::CRON_HOOK, array( __CLASS__, 'heartbeat' ) );
        add_action( 'init', array( __CLASS__, 'ensure_schedule' ) );
        add_action( 'admin_post_pwi_connect_check', array( __CLASS__, 'manual_check' ) );
    }

    public static function schedules( $schedules ) {
        $schedules['pwi_five_minutes'] = array( 'interval' => 300, 'display' => 'Every five minutes (Primewayz Chat Connect)' );
        return $schedules;
    }

    public static function configured() {
        return defined( 'PWI_CHAT_CONNECT_INSTALLATION_ID' ) && is_string( PWI_CHAT_CONNECT_INSTALLATION_ID ) &&
            preg_match( '/^[A-Za-z0-9._:-]{8,128}$/', PWI_CHAT_CONNECT_INSTALLATION_ID ) &&
            defined( 'PWI_CHAT_CONNECT_TOKEN' ) && is_string( PWI_CHAT_CONNECT_TOKEN ) && strlen( PWI_CHAT_CONNECT_TOKEN ) >= 32;
    }

    public static function ensure_schedule() {
        if ( self::configured() ) {
            if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
                wp_schedule_event( time() + 60, 'pwi_five_minutes', self::CRON_HOOK );
            }
        } else {
            wp_clear_scheduled_hook( self::CRON_HOOK );
        }
    }

    public static function deactivate() { wp_clear_scheduled_hook( self::CRON_HOOK ); }

    public static function status() {
        $s = get_option( self::STATUS_KEY, array() );
        return is_array( $s ) ? $s : array();
    }

    private static function request( $action, $payload ) {
        if ( ! self::configured() ) {
            return new WP_Error( 'pwi_connect_unconfigured', 'Installation credentials are not configured in wp-config.php.' );
        }
        $settings = PWI_Settings::get();
        // Deliberately restrict credentials to the trusted production service.
        $base = isset( $settings['api_base_url'] ) ? untrailingslashit( (string) $settings['api_base_url'] ) : '';
        if ( self::API_ORIGIN !== $base ) {
            return new WP_Error( 'pwi_connect_untrusted', 'Chat Connect needs the trusted production API origin.' );
        }
        $response = wp_remote_post( self::API_ORIGIN . '/api/integrations/chat-connect/' . $action, array(
            'timeout' => 12,
            'sslverify' => true,
            'redirection' => 0,
            'headers' => array(
                'Authorization' => 'Bearer ' . PWI_CHAT_CONNECT_TOKEN,
                'Content-Type' => 'application/json',
                'User-Agent' => 'Primewayz-Chat-Connect-WordPress/' . PWI_VERSION,
            ),
            'body' => wp_json_encode( $payload ),
        ) );
        if ( is_wp_error( $response ) ) { return $response; }
        $http = (int) wp_remote_retrieve_response_code( $response );
        $decoded = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( $http < 200 || $http >= 300 || ! is_array( $decoded ) ) {
            return new WP_Error( 'pwi_connect_http', 'Chat Connect service did not accept the request.', array( 'http_status' => $http ) );
        }
        return array( 'http_status' => $http, 'data' => $decoded );
    }

    public static function heartbeat() {
        if ( ! self::configured() ) { return; }
        $settings = PWI_Settings::get();
        $payload = array(
            'installationId' => PWI_CHAT_CONNECT_INSTALLATION_ID,
            'integrationTechnology' => 'wordpress',
            'addonVersion' => PWI_VERSION,
            'widgetVersion' => '1.3.3',
            'frontendVisibility' => 'live' === $settings['chat_mode'] ? 'enabled' : 'disabled',
            'idempotencyKey' => wp_generate_uuid4(),
        );
        $result = self::request( 'heartbeat', $payload );
        $status = array( 'attempted_at' => time(), 'success' => ! is_wp_error( $result ) );
        if ( is_wp_error( $result ) ) {
            $data = $result->get_error_data();
            $status['error'] = $result->get_error_code();
            if ( is_array( $data ) && isset( $data['http_status'] ) ) { $status['http_status'] = (int) $data['http_status']; }
        } else {
            $status['verified_at'] = time();
            $status['http_status'] = $result['http_status'];
        }
        $previous = self::status();
        if ( ! isset( $status['verified_at'] ) && isset( $previous['verified_at'] ) ) { $status['verified_at'] = $previous['verified_at']; }
        update_option( self::STATUS_KEY, $status, false );
    }

    public static function manual_check() {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Access denied', '', array( 'response' => 403 ) ); }
        check_admin_referer( 'pwi_connect_check' );
        self::heartbeat();
        wp_safe_redirect( add_query_arg( array( 'page' => 'primewayz-integration', 'tab' => 'diagnostics', 'connect_checked' => '1' ), admin_url( 'options-general.php' ) ) );
        exit;
    }

    public static function diagnostics_html() {
        $state = self::status();
        $configured = self::configured();
        echo '<hr><h2>Primewayz Chat Connect — Installation</h2>';
        echo '<p>Tenant: <code>pw-infotech</code> · Technology: WordPress · Plugin: <code>' . esc_html( PWI_VERSION ) . '</code></p>';
        echo '<p><strong>Installation credential:</strong> ' . esc_html( $configured ? 'Configured' : 'Not configured' ) . '</p>';
        echo '<p><strong>Heartbeat:</strong> ';
        if ( ! $configured ) { echo 'Not configured'; }
        elseif ( empty( $state['attempted_at'] ) ) { echo 'Not yet reported'; }
        elseif ( ! empty( $state['success'] ) ) { echo 'Last request accepted'; }
        else { echo 'Not accepted (' . esc_html( isset( $state['http_status'] ) ? 'HTTP ' . $state['http_status'] : ( isset( $state['error'] ) ? $state['error'] : 'network error' ) ) . ')'; }
        echo '</p>';
        if ( ! empty( $state['attempted_at'] ) ) {
            echo '<p>Last attempt: ' . esc_html( wp_date( 'Y-m-d H:i:s T', (int) $state['attempted_at'] ) ) . '</p>';
        }
        echo '<p class="description">Connection health is determined by the central Chat Platform from a verified heartbeat, not by this local display.</p>';
        echo '<p class="description">Host/Owner must issue and authorize an installation ID and connector secret. Define <code>PWI_CHAT_CONNECT_INSTALLATION_ID</code> and <code>PWI_CHAT_CONNECT_TOKEN</code> in wp-config.php. Do not reuse <code>PWI_WORDPRESS_CHAT_INTEGRATION_TOKEN</code>.</p>';
        if ( $configured ) {
            echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
            echo '<input type="hidden" name="action" value="pwi_connect_check">';
            wp_nonce_field( 'pwi_connect_check' );
            submit_button( 'Send connection heartbeat', 'secondary', 'submit', false );
            echo '</form>';
        }
    }
}
