<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class PWI_Chat_Loader {
    private static $instance = null;
    private $should_load = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ), 20 );
        add_action( 'wp_footer', array( $this, 'print_config' ), 5 );
        add_action( 'wp_footer', array( $this, 'print_admin_frontend_bar' ), 100 );
    }

    public function enqueue() {
        if ( ! $this->should_load() ) {
            return;
        }
        $file = PWI_PATH . 'assets/chat/pw-chat.js';
        if ( ! is_readable( $file ) ) {
            return;
        }
        wp_enqueue_script( 'pwi-chat', PWI_URL . 'assets/chat/pw-chat.js', array(), $this->asset_version(), true );
        // Email deep-link bridge remains for hosts that relied on the 1.2.1 helper.
        // Widget 1.3.0 also opens on exact ?pw_chat=open natively; the bridge stays idempotent.
        wp_enqueue_script( 'pwi-chat-deep-link', PWI_URL . 'assets/chat/pwi-email-deep-link.js', array( 'pwi-chat' ), PWI_VERSION, true );
        if ( function_exists( 'wp_script_add_data' ) ) {
            wp_script_add_data( 'pwi-chat', 'strategy', 'defer' );
        }
    }

    public function print_config() {
        if ( ! $this->should_load() || ! wp_script_is( 'pwi-chat', 'enqueued' ) ) {
            return;
        }
        $config = $this->runtime_config();
        $json   = wp_json_encode( $config, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
        if ( false === $json ) {
            return;
        }
        echo '<script type="application/json" id="pwi-chat-config">' . $json . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_json_encode creates JSON text, not executable JS.

        $settings = PWI_Settings::get();
        if ( '' !== (string) $settings['launcher_offset_override'] ) {
            $offset = absint( $settings['launcher_offset_override'] );
            echo '<style id="pwi-chat-host-vars">#pw-chat-root{--pw-chat-bottom:' . esc_attr( (string) $offset ) . 'px;}</style>' . "\n";
        }
    }

    private function should_load() {
        if ( null !== $this->should_load ) {
            return $this->should_load;
        }
        $this->should_load = false;
        $settings = PWI_Settings::get();

        if ( 'disabled' === $settings['chat_mode'] || is_admin() || wp_doing_ajax() || $this->is_rest_request() || is_feed() || is_trackback() || $this->is_customize_request() || $this->is_elementor_editor_or_preview() ) {
            return false;
        }
        $is_admin_user = is_user_logged_in() && current_user_can( 'manage_options' );
        $explicit_preview = $this->is_explicit_admin_preview();
        if ( 'preview' === $settings['chat_mode'] && ! $is_admin_user ) {
            return false;
        }
        // In Live mode, administrators get a role-aware control bar rather than silently
        // joining the customer visitor session. They can explicitly launch an isolated preview.
        if ( 'live' === $settings['chat_mode'] && $is_admin_user && ! $explicit_preview ) {
            return false;
        }
        if ( $this->is_excluded_path( $settings['excluded_paths'] ) ) {
            return false;
        }
        $this->should_load = true;
        return true;
    }

    private function is_explicit_admin_preview() {
        return is_user_logged_in()
            && current_user_can( 'manage_options' )
            && isset( $_GET['pwi_chat_preview'] )
            && '1' === sanitize_text_field( wp_unslash( $_GET['pwi_chat_preview'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only preview context.
    }

    public function print_admin_frontend_bar() {
        if ( is_admin() || ! is_user_logged_in() || ! current_user_can( 'manage_options' ) || $this->is_customize_request() || $this->is_elementor_editor_or_preview() ) {
            return;
        }
        $settings = PWI_Settings::get();
        $mode = (string) $settings['chat_mode'];
        $explicit_preview = $this->is_explicit_admin_preview();
        $preview_active = $explicit_preview || 'preview' === $mode;
        $chat_url = add_query_arg( array( 'page' => 'primewayz-integration', 'tab' => 'chat' ), admin_url( 'options-general.php' ) );
        $base_url = remove_query_arg( 'pwi_chat_preview' );
        $preview_url = add_query_arg( 'pwi_chat_preview', '1', $base_url );
        $exit_url = remove_query_arg( 'pwi_chat_preview', $base_url );
        $mode_label = 'live' === $mode ? 'Public chat is LIVE' : ( 'preview' === $mode ? 'Admin Preview Only' : 'Public chat is DISABLED' );
        $tone = 'live' === $mode ? 'live' : ( 'preview' === $mode ? 'preview' : 'off' );
        ?>
        <aside class="pwi-admin-frontbar pwi-admin-frontbar--<?php echo esc_attr( $tone ); ?>" aria-label="Primewayz chat administrator controls">
            <div class="pwi-admin-frontbar__state"><span class="pwi-admin-frontbar__dot" aria-hidden="true"></span><strong><?php echo esc_html( $mode_label ); ?></strong><span>Signed in as WordPress Administrator</span></div>
            <div class="pwi-admin-frontbar__actions">
                <a href="<?php echo esc_url( $chat_url ); ?>">Chat Operations</a>
                <?php if ( 'live' === $mode && ! $explicit_preview ) : ?><a href="<?php echo esc_url( $preview_url ); ?>">Preview visitor chat</a><?php endif; ?>
                <?php if ( $preview_active ) : ?><span class="pwi-admin-frontbar__preview">Visitor preview session</span><?php endif; ?>
                <?php if ( $explicit_preview ) : ?><a href="<?php echo esc_url( $exit_url ); ?>">Exit preview</a><?php endif; ?>
            </div>
        </aside>
        <style id="pwi-admin-frontbar-style">
        .pwi-admin-frontbar{position:fixed;left:50%;bottom:18px;transform:translateX(-50%);z-index:2147483000;display:flex;align-items:center;justify-content:space-between;gap:18px;width:min(900px,calc(100vw - 36px));padding:10px 14px;border:1px solid rgba(15,23,42,.18);border-radius:10px;background:#fff;color:#172033;box-shadow:0 10px 30px rgba(15,23,42,.18);font:13px/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}.pwi-admin-frontbar__state,.pwi-admin-frontbar__actions{display:flex;align-items:center;gap:9px;flex-wrap:wrap}.pwi-admin-frontbar__state span:last-child{color:#5b6472}.pwi-admin-frontbar__dot{width:9px;height:9px;border-radius:50%;background:#64748b;box-shadow:0 0 0 3px #e2e8f0}.pwi-admin-frontbar--live .pwi-admin-frontbar__dot{background:#16a34a;box-shadow:0 0 0 3px #dcfce7}.pwi-admin-frontbar--preview .pwi-admin-frontbar__dot{background:#d97706;box-shadow:0 0 0 3px #fef3c7}.pwi-admin-frontbar__actions a{display:inline-flex;padding:6px 10px;border:1px solid #cbd5e1;border-radius:6px;background:#f8fafc;color:#0b5cab;text-decoration:none;font-weight:600}.pwi-admin-frontbar__actions a:hover{background:#eff6ff;border-color:#93c5fd}.pwi-admin-frontbar__preview{padding:4px 8px;border-radius:999px;background:#fff7ed;color:#9a3412;font-weight:700}@media(max-width:720px){.pwi-admin-frontbar{align-items:flex-start;flex-direction:column;bottom:10px}}
        </style>
        <?php
    }

    private function is_rest_request() {
        return ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( function_exists( 'wp_is_serving_rest_request' ) && wp_is_serving_rest_request() );
    }

    private function is_customize_request() {
        return is_customize_preview() || isset( $_GET['customize_changeset_uuid'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only request context detection.
    }

    private function is_elementor_editor_or_preview() {
        if ( isset( $_GET['elementor-preview'] ) || isset( $_GET['elementor_library'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only request context detection.
            return true;
        }
        if ( isset( $_GET['action'] ) && 'elementor' === sanitize_key( wp_unslash( $_GET['action'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            return true;
        }
        if ( did_action( 'elementor/loaded' ) && class_exists( '\\Elementor\\Plugin' ) ) {
            $plugin = \Elementor\Plugin::$instance;
            if ( isset( $plugin->editor ) && method_exists( $plugin->editor, 'is_edit_mode' ) && $plugin->editor->is_edit_mode() ) {
                return true;
            }
            if ( isset( $plugin->preview ) && method_exists( $plugin->preview, 'is_preview_mode' ) && $plugin->preview->is_preview_mode() ) {
                return true;
            }
        }
        return false;
    }

    private function request_path() {
        $uri  = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
        $path = wp_parse_url( $uri, PHP_URL_PATH );
        return is_string( $path ) && '' !== $path ? '/' . ltrim( $path, '/' ) : '/';
    }

    private function is_excluded_path( $raw ) {
        $current = untrailingslashit( $this->request_path() );
        if ( '' === $current ) {
            $current = '/';
        }
        $items = preg_split( '/[\r\n,]+/', (string) $raw );
        foreach ( $items as $item ) {
            $item = trim( $item );
            if ( '' === $item ) {
                continue;
            }
            $path = wp_parse_url( $item, PHP_URL_PATH );
            if ( ! is_string( $path ) || '' === $path ) {
                continue;
            }
            $path = untrailingslashit( '/' . ltrim( $path, '/' ) );
            if ( '' === $path ) {
                $path = '/';
            }
            if ( $current === $path || ( '/' !== $path && 0 === strpos( $current . '/', $path . '/' ) ) ) {
                return true;
            }
        }
        return false;
    }

    private function asset_version() {
        $build = PWI_PATH . 'assets/chat/BUILD_INFO.json';
        if ( is_readable( $build ) ) {
            $decoded = json_decode( file_get_contents( $build ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local packaged metadata.
            if ( is_array( $decoded ) && ! empty( $decoded['buildVersion'] ) ) {
                $version = sanitize_text_field( $decoded['buildVersion'] );
                if ( preg_match( '/^[A-Za-z0-9._-]+$/', $version ) ) {
                    return $version;
                }
            }
        }
        $file = PWI_PATH . 'assets/chat/pw-chat.js';
        return is_readable( $file ) ? (string) filemtime( $file ) : PWI_VERSION;
    }

    private function runtime_config() {
        $settings = PWI_Settings::get();
        $admin_preview = $this->is_explicit_admin_preview() || ( 'preview' === $settings['chat_mode'] && is_user_logged_in() && current_user_can( 'manage_options' ) );
        return array(
            'apiBaseUrl' => $settings['api_base_url'],
            'siteKey'    => 'primewayz-infotech',
            'siteName'   => 'Primewayz',
            'pageUrl'    => $this->canonical_page_url(),
            'pageType'   => $this->page_type(),
            'isFrontPage'=> is_front_page(),
            'pageContext'=> $admin_preview ? array( 'greeting' => 'Visitor chat preview', 'supportingText' => 'This isolated preview lets an administrator verify the customer chat experience.' ) : $this->page_context(),
            'storageKeys'=> $admin_preview ? array(
                'sessionId' => 'primewayz_chat_admin_preview_session_id',
                'visitorName' => 'primewayz_chat_admin_preview_visitor_name',
                'visitorEmail' => 'primewayz_chat_admin_preview_visitor_email',
                'panelOpen' => 'primewayz_chat_admin_preview_panel_open',
                'openTracked' => 'primewayz_chat_admin_preview_open_tracked',
                'firstLanding' => 'primewayz_chat_admin_preview_first_landing',
            ) : array(),
            'intents'    => array(
                array( 'key' => 'website-development', 'label' => 'Website development' ),
                array( 'key' => 'application-development', 'label' => 'Application development' ),
                array( 'key' => 'crm-erp-integration', 'label' => 'CRM / ERP integration' ),
                array( 'key' => 'ai-automation', 'label' => 'AI and automation' ),
                array( 'key' => 'maintenance-support', 'label' => 'Maintenance and support' ),
                array( 'key' => 'something-else', 'label' => 'Something else' ),
            ),
        );
    }

    private function canonical_page_url() {
        if ( is_singular() ) {
            $url = get_permalink();
            if ( is_string( $url ) && '' !== $url ) {
                return $url;
            }
        }
        if ( is_front_page() ) {
            return home_url( '/' );
        }
        return home_url( $this->request_path() );
    }

    private function page_type() {
        if ( is_front_page() ) return 'home';
        if ( is_search() ) return 'search';
        if ( is_404() ) return '404';
        if ( is_archive() ) return 'archive';
        if ( is_singular( 'post' ) ) return 'post';
        if ( $this->is_case_study() ) return 'case-study';
        if ( is_page() ) return 'page';
        return 'other';
    }

    private function is_case_study() {
        $path = $this->request_path();
        return 0 === strpos( $path, '/success-stories/' ) && '/success-stories/' !== $path;
    }

    private function page_context() {
        if ( is_front_page() ) {
            return array( 'greeting' => 'How can we help?', 'supportingText' => "Tell us what you're trying to build, improve or integrate." );
        }
        if ( $this->is_case_study() ) {
            return array( 'greeting' => 'Want to discuss a similar requirement?', 'supportingText' => 'Tell us about the system, workflow or outcome you are working towards.' );
        }
        if ( is_singular( 'post' ) ) {
            return array( 'greeting' => 'Have a question about this topic?', 'supportingText' => 'Ask us about the ideas, implementation or how they could apply to your organisation.' );
        }
        if ( is_page() && 0 === strpos( $this->request_path(), '/services/' ) ) {
            return array( 'greeting' => 'How can we help with this service?', 'supportingText' => 'Tell us what you need to build, improve or integrate.' );
        }
        return array( 'greeting' => 'How can we help?', 'supportingText' => 'Ask a question or tell us what you need.' );
    }
}
