<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class PWI_Chat_API_Client {
    const API_VERSION = '1';
    const TENANT_KEY = 'pw-infotech';
    const MARKET = 'IN';
    const TRUSTED_PRODUCTION_ORIGIN = 'https://uk.primewayz.com';

    public function has_credential() {
        return defined( 'PWI_WORDPRESS_CHAT_INTEGRATION_TOKEN' ) && is_string( PWI_WORDPRESS_CHAT_INTEGRATION_TOKEN ) && '' !== trim( PWI_WORDPRESS_CHAT_INTEGRATION_TOKEN );
    }

    public function dashboard( $inbox = 'active' ) {
        $inbox = in_array( $inbox, array( 'active', 'archived' ), true ) ? $inbox : 'active';
        return $this->request( array( 'action' => 'dashboard', 'inbox' => $inbox ), 'dashboard' );
    }
    public function diagnostics() { return $this->request( array( 'action' => 'diagnostics' ), 'diagnostics' ); }

    public function conversation( $session_id ) {
        $session_id = $this->validate_session_id( $session_id );
        if ( is_wp_error( $session_id ) ) { return $session_id; }
        return $this->request( array( 'action' => 'conversation', 'sessionId' => $session_id ), 'conversation' );
    }

    public function reply( $session_id, $text, $client_action_id, $actor ) {
        $session_id = $this->validate_session_id( $session_id );
        if ( is_wp_error( $session_id ) ) { return $session_id; }
        $text = trim( (string) $text );
        if ( '' === $text || mb_strlen( $text ) > 4000 ) {
            return new WP_Error( 'pwi_invalid_reply', __( 'Reply must contain between 1 and 4000 characters.', 'primewayz-integration' ) );
        }
        $client_action_id = $this->validate_action_id( $client_action_id );
        if ( is_wp_error( $client_action_id ) ) { return $client_action_id; }
        return $this->request( array(
            'action'         => 'reply',
            'sessionId'      => $session_id,
            'clientActionId' => $client_action_id,
            'actor'          => $this->sanitize_actor( $actor ),
            'text'           => $text,
        ), 'reply' );
    }

    public function resolve( $session_id, $client_action_id, $actor ) {
        return $this->lifecycle_action( 'resolve', $session_id, $client_action_id, $actor );
    }

    public function reopen( $session_id, $client_action_id, $actor ) {
        return $this->lifecycle_action( 'reopen', $session_id, $client_action_id, $actor );
    }

    public function archive( $session_id, $client_action_id, $actor ) {
        return $this->lifecycle_action( 'archive', $session_id, $client_action_id, $actor );
    }

    public function restore( $session_id, $client_action_id, $actor ) {
        return $this->lifecycle_action( 'restore', $session_id, $client_action_id, $actor );
    }

    public function delete_conversation( $session_id, $client_action_id, $actor ) {
        return $this->lifecycle_action( 'delete', $session_id, $client_action_id, $actor );
    }

    private function lifecycle_action( $action, $session_id, $client_action_id, $actor ) {
        $session_id = $this->validate_session_id( $session_id );
        if ( is_wp_error( $session_id ) ) { return $session_id; }
        $client_action_id = $this->validate_action_id( $client_action_id );
        if ( is_wp_error( $client_action_id ) ) { return $client_action_id; }
        return $this->request( array(
            'action'         => $action,
            'sessionId'      => $session_id,
            'clientActionId' => $client_action_id,
            'actor'          => $this->sanitize_actor( $actor ),
        ), $action );
    }

    private function validate_session_id( $session_id ) {
        $session_id = sanitize_text_field( (string) $session_id );
        if ( '' === $session_id || strlen( $session_id ) > 255 || ! preg_match( '/^[A-Za-z0-9._:-]+$/', $session_id ) ) {
            return new WP_Error( 'pwi_invalid_session', __( 'Invalid conversation reference.', 'primewayz-integration' ) );
        }
        return $session_id;
    }

    private function validate_action_id( $client_action_id ) {
        $client_action_id = sanitize_text_field( (string) $client_action_id );
        if ( '' === $client_action_id || strlen( $client_action_id ) > 128 || ! preg_match( '/^[A-Za-z0-9._:-]+$/', $client_action_id ) ) {
            return new WP_Error( 'pwi_invalid_action_id', __( 'Invalid action reference.', 'primewayz-integration' ) );
        }
        return $client_action_id;
    }

    private function sanitize_actor( $actor ) {
        $actor = is_array( $actor ) ? $actor : array();
        return array(
            'externalUserId' => sanitize_text_field( isset( $actor['externalUserId'] ) ? (string) $actor['externalUserId'] : '' ),
            'displayName'    => sanitize_text_field( isset( $actor['displayName'] ) ? (string) $actor['displayName'] : 'WordPress Administrator' ),
        );
    }

    private function endpoint() {
        $settings = PWI_Settings::get();
        $base_url = isset( $settings['api_base_url'] ) ? untrailingslashit( (string) $settings['api_base_url'] ) : '';
        $parts = wp_parse_url( $base_url );
        if ( ! is_array( $parts ) || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
            return new WP_Error( 'pwi_untrusted_api_host', __( 'Operational API host is not trusted.', 'primewayz-integration' ) );
        }
        if ( ! empty( $parts['user'] ) || ! empty( $parts['pass'] ) || isset( $parts['query'] ) || isset( $parts['fragment'] ) ) {
            return new WP_Error( 'pwi_untrusted_api_host', __( 'Operational API host is not trusted.', 'primewayz-integration' ) );
        }
        $scheme = strtolower( (string) $parts['scheme'] );
        $host = strtolower( (string) $parts['host'] );
        $path = isset( $parts['path'] ) ? untrailingslashit( (string) $parts['path'] ) : '';
        $is_production = self::TRUSTED_PRODUCTION_ORIGIN === $base_url && ! isset( $parts['port'] ) && '' === $path;
        $environment = function_exists( 'wp_get_environment_type' ) ? wp_get_environment_type() : 'production';
        $is_local = in_array( $environment, array( 'local', 'development' ), true ) && 'http' === $scheme && in_array( $host, array( 'localhost', '127.0.0.1' ), true );
        if ( ! $is_production && ! $is_local ) {
            return new WP_Error( 'pwi_untrusted_api_host', __( 'Operational API host is not trusted. Production requests are restricted to the Primewayz UK Host.', 'primewayz-integration' ) );
        }
        return $base_url . '/api/integrations/wordpress/chat';
    }

    private function request( $body, $action ) {
        if ( ! $this->has_credential() ) {
            return new WP_Error( 'pwi_not_configured', __( 'Operational API credential is not configured.', 'primewayz-integration' ) );
        }
        $endpoint = $this->endpoint();
        if ( is_wp_error( $endpoint ) ) {
            return $endpoint;
        }
        $request_id = wp_generate_uuid4();
        $response = wp_remote_post( $endpoint, array(
            'timeout'   => 10,
            'sslverify' => true,
            'headers'   => array(
                'Authorization' => 'Bearer ' . PWI_WORDPRESS_CHAT_INTEGRATION_TOKEN,
                'Content-Type'  => 'application/json',
                'X-Request-ID'  => $request_id,
                'User-Agent'    => 'Primewayz-Integration/' . PWI_VERSION . '; ' . home_url( '/' ),
            ),
            'body' => wp_json_encode( $body ),
        ) );
        if ( is_wp_error( $response ) ) {
            return new WP_Error( 'pwi_network', __( 'Unable to reach the Primewayz chat service.', 'primewayz-integration' ), array( 'request_id' => $request_id ) );
        }
        $code = (int) wp_remote_retrieve_response_code( $response );
        $returned_request_id = sanitize_text_field( wp_remote_retrieve_header( $response, 'x-request-id' ) );
        if ( '' === $returned_request_id ) { $returned_request_id = $request_id; }
        if ( 200 !== $code ) {
            $messages = array(
                400 => __( 'The chat operation could not be processed. Check the submitted values.', 'primewayz-integration' ),
                401 => __( 'Operational API authentication failed. Check the server-side integration credential.', 'primewayz-integration' ),
                403 => __( 'This integration is not permitted to perform the requested operation.', 'primewayz-integration' ),
                404 => 'conversation' === $action ? __( 'Conversation is no longer available.', 'primewayz-integration' ) : __( 'The requested chat resource is not available.', 'primewayz-integration' ),
                409 => __( 'This conversation is not currently in a state that permits that action.', 'primewayz-integration' ),
                429 => __( 'The chat service is receiving too many requests. Please retry shortly.', 'primewayz-integration' ),
                503 => __( 'The Primewayz chat service is temporarily unavailable.', 'primewayz-integration' ),
            );
            $data = array( 'http_status' => $code, 'request_id' => $returned_request_id );
            if ( 429 === $code ) { $data['retry_after'] = sanitize_text_field( wp_remote_retrieve_header( $response, 'retry-after' ) ); }
            return new WP_Error( 'pwi_http_' . $code, isset( $messages[ $code ] ) ? $messages[ $code ] : __( 'The Primewayz chat service returned an unexpected response.', 'primewayz-integration' ), $data );
        }
        $decoded = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( ! is_array( $decoded ) || empty( $decoded['ok'] ) || ! isset( $decoded['apiVersion'], $decoded['tenant'], $decoded['data'] ) || ! is_array( $decoded['tenant'] ) || ! is_array( $decoded['data'] ) ) {
            return new WP_Error( 'pwi_invalid_response', __( 'The Primewayz chat service returned an invalid response.', 'primewayz-integration' ), array( 'request_id' => $returned_request_id ) );
        }
        if ( self::API_VERSION !== (string) $decoded['apiVersion'] ) {
            return new WP_Error( 'pwi_api_version', __( 'Unsupported operational API version.', 'primewayz-integration' ), array( 'request_id' => $returned_request_id ) );
        }
        $tenant_key = isset( $decoded['tenant']['key'] ) ? (string) $decoded['tenant']['key'] : '';
        $market = isset( $decoded['tenant']['market'] ) ? (string) $decoded['tenant']['market'] : ( isset( $decoded['market'] ) ? (string) $decoded['market'] : '' );
        if ( self::TENANT_KEY !== $tenant_key || self::MARKET !== $market ) {
            return new WP_Error( 'pwi_unexpected_tenant', __( 'Unexpected integration tenant.', 'primewayz-integration' ), array( 'request_id' => $returned_request_id ) );
        }
        update_option( 'pwi_chat_last_success_at', time(), false );
        update_option( 'pwi_chat_last_request_id', $returned_request_id, false );
        $decoded['_requestId'] = $returned_request_id;
        return $decoded;
    }
}
