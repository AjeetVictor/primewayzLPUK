<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) { exit; }
delete_option( 'pwi_settings' );
delete_option( 'pwi_chat_last_success_at' );
delete_option( 'pwi_chat_last_request_id' );
