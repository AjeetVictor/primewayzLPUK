<?php
/**
 * Plugin Name: Primewayz Chat Connect
 * Description: WordPress integration layer for the Primewayz public chat widget and delegated tenant chat administration.
 * Version: 1.3.3
 * Author: Primewayz Infotech Pvt. Ltd.
 * Requires PHP: 7.4
 * Text Domain: primewayz-integration
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
define( 'PWI_VERSION', '1.3.3' );
define( 'PWI_PATH', plugin_dir_path( __FILE__ ) );
define( 'PWI_URL', plugin_dir_url( __FILE__ ) );
define( 'PWI_OPTION_KEY', 'pwi_settings' );
require_once PWI_PATH . 'includes/class-pwi-settings.php';
require_once PWI_PATH . 'includes/class-pwi-chat-loader.php';
require_once PWI_PATH . 'includes/class-pwi-chat-api-client.php';
require_once PWI_PATH . 'includes/class-pwi-chat-admin.php';
require_once PWI_PATH . 'includes/class-pwi-chat-connect.php';
function pwi_bootstrap(){ PWI_Settings::instance(); PWI_Chat_Loader::instance(); PWI_Chat_Admin::instance(); PWI_Chat_Connect::init(); }
add_action( 'plugins_loaded', 'pwi_bootstrap' );

register_deactivation_hook( __FILE__, array( 'PWI_Chat_Connect', 'deactivate' ) );
